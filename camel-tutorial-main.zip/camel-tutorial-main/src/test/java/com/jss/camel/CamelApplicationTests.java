package com.jss.camel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamelApplicationTests {

	@Test
	void contextLoads() {
	}

}
